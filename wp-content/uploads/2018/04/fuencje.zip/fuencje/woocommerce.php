<?php get_header(); ?>
<div class="container">
      <div class="content-holder">      
    		 <section class="site-contentarea sitefull"> 
                <div class="contentbox">
					<?php woocommerce_content(); ?>
                      <div class="clear"></div>        				      
                </div>
            </section><!-- section-->
          
    </div><!-- .content-holder --> 
 </div><!-- .container --> 
<?php get_footer(); ?>