=====================================
Florence IT Free SEO Friendly WordPress Template
=====================================
Theme Name      :   Florence IT
Theme URI         :   http://zylothemes.com/themes/free-seo-friendly-wordpress-template/
Version                :   2.0.4
Tested up to        :   WP 4.7.4
Author                  :   Florence IT
Author URI          :   http://www.zylothemes.com/
license                :   GNU General Public License v3.0
License URI       :   http://www.gnu.org/licenses/gpl.html
==========================================================
Florence IT WordPress Theme bundles the following third-party resources:
==========================================================
All js that have been used are within folder /js of theme.

jQuery Owl carousel v2.0.0, http://owlgraphic.com/owlcarousel
Copyright (c) 2013, MIT License, https://github.com/OwlFonk/OwlCarousel

jQuery Nivo Slider:
Copyright 2012, Dev7studios, under MIT license
http://nivo.dev7studios.com

Roboto - https://www.google.com/fonts/specimen/Roboto
License: Distributed under the terms of the Apache License, version 2.0 		http://www.apache.org/licenses/

Images used from Pixabay.
Pixabay provides images under CC0 license 		
(https://creativecommons.org/about/)

*screenshot.png
https://pixabay.com/en/golden-gate-bridge-san-francisco-690358/
      

For any help you can mail us at zylothemes@gmail.com


==============================================
Theme copyright/license attribution
==============================================

Florence IT Theme is derived from Businessweb Plus, Copyright Grace Themes(gracethemes.com), 2017.
Businessweb Plus WordPress Theme is released under the terms of GNU GPL